#!/usr/bin/env python

"""
A filter that _________.
"""

import fileinput


def process(line):
    """For each line of input, _____."""
    print(line[:-1])


for line in fileinput.input():
    process(line)
